using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ScreenHandler : MonoBehaviour
{
    public GameObject Scr1;
    public GameObject Scr2;
    public GameObject Scr3;

    // Метод, запускаемый при старте сцены.
    void Start()
    {        
       Scr2.SetActive(false);
       Scr3.SetActive(false);
    }     

    // Метод, запускаемый при каждом новом кадре.
    void Update()
    {

    }
    //Метод перехода к экрану 3
    public void OpenScr3(){

        Scr1.SetActive(false);
        Scr3.SetActive(true);
    }

    //Метод перехода к экрану 2
    public void OpenScr2(){

        Scr1.SetActive(false);
        Scr2.SetActive(true);
    }

    //Метод перехода к экрану 1
    public void OpenScr1(){

        Scr1.SetActive(true);
        Scr2.SetActive(false);
    }

    //Метод открытия ссылки на сайт организации
    public void OpenURL(){
        Application.OpenURL("https://tksu.ru/");
    }

    //Метод выхода из приложения
    public void ExitApp(){

        Application.Quit();

    }

    //Метод открытия игровой сцены
    /*public void SceneLoad(int index){
        SceneManager.LoadScene(index);
    }*/
}
